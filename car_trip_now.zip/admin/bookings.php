<?php
// Redirect to new trips page
header('Location: trips.php');
exit();
?>
