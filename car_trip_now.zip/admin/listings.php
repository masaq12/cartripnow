<?php
// Redirect to new vehicles page
header('Location: vehicles.php');
exit();
?>
